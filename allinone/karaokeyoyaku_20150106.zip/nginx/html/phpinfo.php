<?php
  phpinfo();
?>