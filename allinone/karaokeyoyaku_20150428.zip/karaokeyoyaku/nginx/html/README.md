KaraokeRequestorWeb
===================

持ち込みカラオケを行う際に、カラオケ動画をブラウザ上でリクエストをするシステム。

目的
持ち込みカラオケを行う際に動画ファイルを入れたディスクを持ち寄ってカラオケ動画再生用PCに接続。
参加者が手持ちの端末のブラウザから動画ファイルを検索しリクエストとして登録する。
機材係がリクエストされた内容を確認できるようにする。


必要な環境
- Everything Search Engine ( http://www.voidtools.com/ )
- Web Server (nginx http://nginx.org/en/index.html 等)
- PHP実行環境 ( http://php.net/ )

使用方法は
http://bee7813993.github.io/KaraokeRequestorWeb/
を参照

最初のセットアップがそこそこ面倒なことが分かったので、
簡単にセットアップツールができるまで、Windowsのリモートアシスタンスでセットアップのお手伝いをしようと思います。
何らかの方法(twitter,mixi,facebookなど)で私に連絡を取ってもらえればお手伝いしますのでご連絡お待ちしています。

