<?php
include 'checkserver.php';

service_checkrestart();

//$RET = 
//echo $RET ? 'true' : 'false';

?>