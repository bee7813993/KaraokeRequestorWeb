<?php
  http_redirect("request.php");
?>